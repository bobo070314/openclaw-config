---
name: "install-find-skills"
description: "安装find-skills工具以查找和安装技能"
---

# 安装find-skills工具

为了能够使用 `find-skills` 工具，我们需要先安装它。以下是安装步骤：

## 安装步骤

1. **安装find-skills**：使用 `qclaw-env` 技能安装 `find-skills` 工具。
   ```bash
   qclaw-env install find-skills
   ```

2. **验证安装**：安装完成后，验证 `find-skills` 是否正确安装。
   ```bash
   find-skills --version
   ```
