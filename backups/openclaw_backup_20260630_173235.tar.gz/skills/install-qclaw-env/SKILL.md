---
name: "install-qclaw-env"
description: "安装qclaw-env工具以管理环境配置"
---

# 安装qclaw-env工具

为了能够使用 `qclaw-env` 工具，我们需要先安装它。以下是安装步骤：

## 安装步骤

1. **安装qclaw-env**：使用 `find-skills` 技能查找并安装 `qclaw-env` 工具。
   ```bash
   find-skills install qclaw-env
   ```

2. **验证安装**：安装完成后，验证 `qclaw-env` 是否正确安装。
   ```bash
   qclaw-env --version
   ```
