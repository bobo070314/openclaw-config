---
name: "install-cron-tool"
description: "安装cron工具以管理定时任务"
---

# 安装cron工具

为了能够管理定时任务，我们需要先安装 `cron` 工具。以下是安装步骤：

## 安装步骤

1. **安装cron**：使用 `qclaw-env` 技能安装 `cron` 工具。
   ```bash
   qclaw-env install cron
   ```

2. **验证安装**：安装完成后，验证 `cron` 是否正确安装。
   ```bash
   cron -v
   ```

3. **配置cron**：根据需要配置 `cron` 服务。
   ```bash
   systemctl enable cron
   systemctl start cron
   ```
