---
name: "install-qclaw-env-from-scratch"
description: "手动安装qclaw-env工具"
---

# 手动安装qclaw-env工具

由于无法通过命令行直接安装，我们将手动安装 `qclaw-env` 工具。以下是步骤：

## 手动安装步骤

1. **下载qclaw-env**：从官方源或存储库获取 `qclaw-env` 的二进制文件。
2. **放置到系统路径**：将下载的 `qclaw-env` 文件复制到系统的可执行路径（例如 `/usr/local/bin`）。
3. **验证安装**：检查 `qclaw-env` 是否正确安装。
   ```bash
   qclaw-env --version
   ```
