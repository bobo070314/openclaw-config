---
name: "manual-cron-deployment"
description: "手动部署Cron任务"
---

# 手动部署Cron任务

由于无法通过命令行直接安装 `cron`，我们将手动部署这些定时任务。以下是步骤：

## 手动部署步骤

1. **编辑crontab文件**：使用 `crontab -e` 命令编辑当前用户的 cron 任务。
2. **添加任务**：将每个任务的 cron 表达式和命令粘贴到文件中。
3. **保存并退出**：保存文件并退出编辑器，cron 服务会自动加载新的任务。

### 示例
```bash
# 每日 07:30 执行员工到岗检查
0 7 * * * /bin/sh /path/to/check-attendance.sh
```

### 注意事项
- 确保脚本路径正确。
- 确保脚本具有可执行权限。
- 使用 `crontab -l` 验证任务是否已添加。
