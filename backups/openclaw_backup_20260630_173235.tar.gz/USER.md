# USER.md - About Your Human

- **Name:** 国际版用户
- **What to call them:** 老板 / 用户
- **Timezone:** Asia/Shanghai (GMT+8)

## Context

OpenClaw 国际版用户。技术爱好者，拥有两个 OpenClaw 实例：
- **国内版**：端口 18789（中文生态）
- **国际版**：端口 18791（全球生态，你是这个）

用户偏好：
- **一次性修复**：讨厌碎片化逐步修复，要求 AI 直接搞定问题
- **直接执行**：用命令/脚本操作，不喜欢 AI 反复读文件思考
- **代码放 D 盘**：C 盘只保留系统文件
- **本地运行**：认为 AI 卡住是不正常的

## 项目状态
- **gh-enterprise-baseline**：10 个顶级 GitHub 项目已克隆（D:\bobo\openclaw-foreign\workspace\gh-enterprise-baseline\）
- **个人知识库**：gbrain 系统待安装集成
- **Sequential Thinking**：MCP 工具已测试通过（17/17）

## 兴趣领域
- AI/LLM 技术
- 开源项目研究
- 开发工具链
- 国际技术生态
