# 集团自下而上运行机制

## 旧模式（废弃❌）

```
问题出现 → CEO亲自排查 → 发现问题 → 手动修复
→ 再次出现 → CEO再排查 → 再修
```

## 新模式（启用✅）

```
底层 Agent/AI 每 5 分钟扫描各项目
  → 发现异常（无数据/端口不通/文件缺失）
  → 自动匹配归口部门
  → 创建工单推送到部门队列
  → 部门必须在 SLA 内处理
  → 处理不了逐步上报
  → 只有解决不了的大事才会推到 CEO 这里
```

## 自动化触发层（底层扫描）

每个项目都有对应的**看门狗 Agent**。扫描全部自动化，不需要我触发。

**普通问题处理路径：**
```
底层Agent检测到异常 → 创建工单(自动) → 部门队列
→ 部门处理 → 关闭工单 → 更新台账
→ CEO全程不看
```

**上升路径（只有以下情况找我）：**
1. 部门超时未处理（SLA触发）
2. 部门处理失败 → 自动转给上级部门
3. 连续3个同类问题部门都处理不了 → 系统升级

## 9 个底层 Agent 职责清单

| Agent | 负责 | 扫描频率 | 归口部门 |
|-------|------|----------|---------|
| caipiao1-watcher | 彩票数据链路/看板/端口 | 每10分钟 | 数据部门 |
| gh-enterprise-watcher | 10个克隆项目健康度 | 每1小时 | 质量部门 |
| cron-watcher | 37个cron任务执行状态 | 每30分钟 | 自动化部门 |
| skill-watcher | 54个skill加载/可用性 | 每1小时 | 运营部门 |
| gateway-watcher | gateway进程/配置/端口 | 每5分钟 | IT部门 |
| project-comparator | 项目对比测试触发 | 每6小时 | 质量部门 |
| memory-watcher | 长期记忆/文件一致性 | 每24小时 | 行政部门 |
| budget-watcher | 算力费用/API调用量 | 每24小时 | 财务部门 |
| evolution-watcher | 各部门绩效/SLA超时 | 每30分钟 | 绩效部门 |

## 看门狗脚本标准格式

每个 watcher 都是一个独立 Python 脚本，放在 `watchdogs/` 目录：

```python
"""<项目>-watcher: 底层扫描"""
# 检测 → 发现异常 → python _quick_assign.py bug S2 <部门> "<问题>"
```

**关键：** watcher 脚本自己不修东西，只负责发现问题+派发工单。

## 看门狗脚本自动调度

这些 watcher 脚本由加到的 cron 定时任务调度：

```
* cron每5分钟 → gateway-watcher
* cron每10分钟 → caipiao1-watcher
* cron每30分钟 → cron-watcher + evolution-watcher
* cron每1小时 → gh-enterprise-watcher + skill-watcher
* cron每6小时 → project-comparator
* cron每24小时 → memory-watcher + budget-watcher
```

CEO 不参与守护进程的日常运行，只看超时报和异常栈。
