# Data Department 待处理任务队列
| ID | 等级 | 时限 | 状态 | 创建 | 描述 |
|----|------|------|------|------|------|
| TASK-20260630_171208 | S1 | 10min | resolved | 06-30 17:12 | caipiao1数据链路断点: bet_records.json结构不匹配, comparator加载失败 |