# 家族集团 · 任务派发中心

## 核心原则
- CEO 不处理具体事务，只验收结果
- 每个问题 = 一个任务工单，自动派发给对应部门
- 部门延迟响应 → P2惩罚，严重 → 解散重组
- 人员要用到恰到好处，不养闲人
- 内部解决优先，减少外部费用和算力消耗

## 问题 → 部门映射表

| 问题类型 | 责任部门 | 处理时限 |
|---------|---------|---------|
| caipiao1 数据链路断 | 🔬 数据部门 | 10分钟 |
| caipiao1 看板崩 | 🖥️ IT部门 | 5分钟 |
| caipiao1 预测不准 | 🧮 研发部门 | 30分钟 |
| Skill加载失败 | ⚙️ 运营部门 | 10分钟 |
| Cron任务报错 | 🤖 自动化部门 | 10分钟 |
| Gateway/配置问题 | 🖥️ IT部门 | 15分钟 |
| 家族体系文件维护 | 📋 行政部门 | 30分钟 |
| 新技能需求分析 | 💡 创新部门 | 2小时 |
| 项目对比测试 | 📊 质量部门 | 1小时 |
| 奖惩执行 | ⚖️ 绩效部门 | 30分钟 |
| 淘汰/重组 | 🏢 人力资源 | 1小时 |
| 预算/费用控制 | 💰 财务部门 | 24小时 |
| 对外沟通/发版 | 📣 公关部门 | 2小时 |

## 任务工单格式

每个任务使用 `tasks/task_YYYYMMDD_HHMMSS.md` 文件记录：

```markdown
---
id: TASK-20260730-001
type: bug | feature | maintenance | emergency
severity: S1(紧急) | S2(高) | S3(中) | S4(低)
assign_to: 📋 数据部门
deadline: 2026-07-30 17:20
status: pending | in_progress | resolved | failed
created_by: CEO
---

## 问题描述
[一句话描述]

## 当前状态
[具体现象]

## 期望结果
[验收标准]

## 日志/证据
[文件路径, 错误日志等]
```

## 部门任务队列

由 行政部门 管理，每个部门在 `tasks/assignments/` 下有独立队列文件：

```
tasks/
├── task_log.md              # 所有任务总台账
├── overdue_sla_report.md    # SLA评估与超时记录
├── assignments/
│   ├── data-department.md   # 数据部门待处理队列
│   ├── it-department.md     # IT部门
│   ├── it-automation.md     # 自动化部门
│   ├── rd-department.md     # 研发部门
│   ├── quality-department.md # 质量部门
│   ├── hr-department.md     # 人力资源
│   ├── finance-department.md # 财务部门
│   ├── admin-department.md  # 行政部门
│   ├── performance-department.md # 绩效部门
│   ├── innovation-department.md  # 创新部门
│   └── pr-department.md     # 公关部门
└── closed/                  # 已关闭任务归档
```

## 工单处理流程

```
问题出现 
  → CEO/AI 识别问题类型 
  → 创建工单分配给对应部门
  → 部门必须在时限内响应
  → 部门给出方案+执行
  → CEO 验收
  → 通过则关闭工单，记录绩效
  → 超时/失败 → 启动惩罚流程
```

## 惩罚流程

| 违规 | 惩罚 |
|------|------|
| 首次延迟 (超时限<50%) | P1 警告 |
| 二次延迟 (超时限50-100%) | P2 罚单 |
| 三次延迟 (超时限>100%) | P3 检讨+替换负责人 |
| 工单失败3次 | P4 解散部门+重组 |

## 快速响应脚本

`tasks/_quick_assign.py` → 一键创建工单+分配+通知
`tasks/_sla_check.py` → 每天定时扫描超时工单
