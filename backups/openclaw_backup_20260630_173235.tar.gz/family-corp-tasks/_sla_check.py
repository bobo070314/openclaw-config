"""SLA 超时检查 — 每天定时扫描超时工单"""
import json
from pathlib import Path
from datetime import datetime

TASKS_DIR = Path(r"D:\bobo\openclaw-foreign\workspace\family-corp-tasks")
ASSIGN_DIR = TASKS_DIR / "assignments"

# 部门时限(分钟)
DEPT_TIMEOUT = {
    "数据部门": 10, "IT部门": 15, "研发部门": 30, "质量部门": 60,
    "运营部门": 10, "自动化部门": 10, "行政部门": 30, "人力资源": 60,
    "财务部门": 1440, "绩效部门": 30, "创新部门": 120, "公关部门": 120,
}

def check_overdue():
    """检查所有待处理工单的超时情况"""
    now = datetime.now()
    results = {"overdue": [], "urgent": [], "ok": []}
    
    for detail_file in sorted(TASKS_DIR.glob("TASK-*.md")):
        text = detail_file.read_text(encoding="utf-8")
        
        # 解析工单 ID 和状态
        task_id = detail_file.stem
        
        # 检查是否已关闭
        if "- [x]" in text or "status: resolved" in text:
            continue
        
        # 提取部门 + 时限
        dept = "unknown"
        dl_min = 30
        created_str = ""
        
        for line in text.split("\n"):
            line = line.strip()
            if line.startswith("assign_to:"):
                dept = line.split(":", 1)[1].strip()
            if line.startswith("deadline:"):
                # deadline: 2026-07-30 17:20 +10min
                parts = line.split("+")
                if len(parts) > 1:
                    dl_min = int(parts[1].replace("min", "").strip())
            if line.startswith("created:"):
                created_str = line.split(":", 1)[1].strip()
        
        # 计算已过时间
        if created_str:
            try:
                created_time = datetime.strptime(created_str, "%Y-%m-%d %H:%M")
                elapsed = (now - created_time).total_seconds() / 60
                ratio = elapsed / dl_min
                
                entry = {
                    "id": task_id,
                    "dept": dept,
                    "elapsed_min": round(elapsed, 1),
                    "deadline_min": dl_min,
                    "ratio": round(ratio, 2),
                }
                
                if ratio >= 1.0:
                    results["overdue"].append(entry)
                elif ratio >= 0.7:
                    results["urgent"].append(entry)
                else:
                    results["ok"].append(entry)
            except ValueError:
                pass
    
    return results


def generate_report(results):
    """生成超时报告"""
    report_lines = []
    report_lines.append("# 部门 SLA 考核报告")
    report_lines.append(f"检查时间: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    report_lines.append("")
    
    overdue = results["overdue"]
    urgent = results["urgent"]
    
    if overdue:
        report_lines.append(f"## ⛔ 超时工单 ({len(overdue)}个)")
        report_lines.append("")
        for o in overdue:
            severity = "P2 罚单" if o["ratio"] < 1.5 else "P3 检讨+替换"
            if o["ratio"] >= 3:
                severity = "P4 解散部门!"
            report_lines.append(f"- **{o['id']}** ({o['dept']})")
            report_lines.append(f"  已过 {o['elapsed_min']}min / 时限 {o['deadline_min']}min")
            report_lines.append(f"  建议惩罚: {severity}")
            report_lines.append("")
    
    if urgent:
        report_lines.append(f"## ⚠️ 即将超时 ({len(urgent)}个)")
        report_lines.append("")
        for u in urgent:
            report_lines.append(f"- **{u['id']}** ({u['dept']}): 已过 {u['elapsed_min']}min / {u['deadline_min']}min")
    
    if not overdue and not urgent:
        report_lines.append("## ✅ 全部工单按时处理")
        report_lines.append("")
    
    report_lines.append(f"总工单: {len(overdue)+len(urgent)+len(results['ok'])}")
    report_lines.append(f"正常: {len(results['ok'])}")
    report_lines.append(f"即将超时: {len(urgent)}")
    report_lines.append(f"已超时: {len(overdue)}")
    
    return "\n".join(report_lines)


if __name__ == "__main__":
    results = check_overdue()
    report = generate_report(results)
    print(report)
    
    # 写入报告
    report_path = TASKS_DIR / "overdue_sla_report.md"
    report_path.write_text(report, encoding="utf-8")
    
    if results["overdue"]:
        print(f"\n⚠️ {len(results['overdue'])}个工单超时，惩罚流程启动")
