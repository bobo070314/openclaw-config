"""任务工单自动派发系统"""
import json, sys, os
from pathlib import Path
from datetime import datetime

TASKS_DIR = Path(r"D:\bobo\openclaw-foreign\workspace\family-corp-tasks")
ASSIGN_DIR = TASKS_DIR / "assignments"
CLOSED_DIR = TASKS_DIR / "closed"
TEMPLATE_FILE = TASKS_DIR / "task-dispatch-system.md"

# 确保目录
for d in [ASSIGN_DIR, CLOSED_DIR]:
    d.mkdir(parents=True, exist_ok=True)

# 部门 → 文件名映射
DEPT_FILES = {
    "数据部门": "data-department.md",
    "IT部门": "it-department.md",
    "研发部门": "rd-department.md",
    "质量部门": "quality-department.md",
    "运营部门": "operations-department.md",
    "自动化部门": "automation-department.md",
    "行政部门": "admin-department.md",
    "人力资源": "hr-department.md",
    "财务部门": "finance-department.md",
    "绩效部门": "performance-department.md",
    "创新部门": "innovation-department.md",
    "公关部门": "pr-department.md",
}

# 时限映射(分钟)
DEPT_TIMEOUT = {
    "数据部门": 10,
    "IT部门": 15,
    "研发部门": 30,
    "质量部门": 60,
    "运营部门": 10,
    "自动化部门": 10,
    "行政部门": 30,
    "人力资源": 60,
    "财务部门": 1440,
    "绩效部门": 30,
    "创新部门": 120,
    "公关部门": 120,
}

def load_task_log():
    """加载任务台账"""
    path = TASKS_DIR / "task_log.md"
    if path.exists():
        text = path.read_text(encoding="utf-8")
        if "## 任务台账" in text:
            return text
    return """# 任务台账

| ID | 类型 | 等级 | 部门 | 时限 | 状态 | 创建时间 | 描述 |
|----|------|------|------|------|------|----------|------|
"""

def load_queue(dept):
    """加载部门队列文件"""
    fname = DEPT_FILES.get(dept)
    if not fname:
        return "# 待处理任务\n\n| ID | 等级 | 时限 | 状态 | 创建 | 描述 |\n|----|------|------|------|------|------|\n"
    path = ASSIGN_DIR / fname
    if path.exists():
        return path.read_text(encoding="utf-8")
    return f"# {dept} 待处理任务队列\n\n| ID | 等级 | 时限 | 状态 | 创建 | 描述 |\n|----|------|------|------|------|------|\n"


def create_task(task_type: str, severity: str, dept: str, description: str):
    """创建工单并派发"""
    now = datetime.now()
    ts = now.strftime("%Y%m%d_%H%M%S")
    task_id = f"TASK-{ts}"
    deadline_min = DEPT_TIMEOUT.get(dept, 30)
    
    task_entry = {
        "id": task_id,
        "type": task_type,
        "severity": severity,
        "dept": dept,
        "deadline_min": deadline_min,
        "status": "pending",
        "created": now.strftime("%Y-%m-%d %H:%M"),
        "description": description,
    }
    
    # 1) 保存工单详情文件
    detail_path = TASKS_DIR / f"{task_id}.md"
    detail = f"""---
id: {task_id}
type: {task_type}
severity: {severity}
assign_to: {dept}
deadline: {now.strftime('%Y-%m-%d %H:%M')} +{deadline_min}min
status: pending
created_by: CEO
---

## 工单：{description}

### 问题
- 类型: {task_type}
- 等级: {severity}
- 责任部门: {dept}

### 处理时限
- 创建: {now.strftime('%Y-%m-%d %H:%M')}
- 截止: {now.strftime('%Y-%m-%d %H:%M')} (创建后{deadline_min}分钟内)

### 验收标准
1. 问题定位
2. 执行修复
3. 验证通过
4. 报告CEO

### 状态
- [ ] 待处理
- [ ] 处理中
- [ ] 已完成
"""
    detail_path.write_text(detail.strip(), encoding="utf-8")

    # 2) 加入任务台账
    log_text = load_task_log()
    log_lines = log_text.split("\n")
    new_row = f"| {task_id} | {task_type} | {severity} | {dept} | {deadline_min}min | pending | {now.strftime('%m-%d %H:%M')} | {description} |"
    # 插在表之后(第二行)
    if "|---|---" in log_lines:
        insert_at = 2
        for i, line in enumerate(log_lines):
            if line.startswith("| ") and not line.startswith("|----") and not line.startswith("| ID"):
                insert_at = i
                break
        log_lines.insert(insert_at + 1, new_row)
    else:
        log_lines.append(new_row)
    (TASKS_DIR / "task_log.md").write_text("\n".join([l for l in log_lines if l]), encoding="utf-8")

    # 3) 加入部门队列
    queue_text = load_queue(dept)
    queue_lines = queue_text.split("\n")
    q_row = f"| {task_id} | {severity} | {deadline_min}min | pending | {now.strftime('%m-%d %H:%M')} | {description} |"
    if "|---|---" in queue_lines:
        insert_at = 2
        for i, line in enumerate(queue_lines):
            if line.startswith("| ") and not line.startswith("|----") and not line.startswith("| ID"):
                insert_at = i
                break
        queue_lines.insert(insert_at + 1, q_row)
    else:
        queue_lines.append(q_row)
    
    fname = DEPT_FILES.get(dept, f"{dept}.md")
    (ASSIGN_DIR / fname).write_text("\n".join([l for l in queue_lines if l]), encoding="utf-8")

    print(f"✅ 工单已创建: {task_id}")
    print(f"   部门: {dept}")
    print(f"   等级: {severity}, 时限: {deadline_min}min")
    print(f"   描述: {description}")
    print(f"   文件: {detail_path}")
    return task_entry


if __name__ == "__main__":
    if len(sys.argv) < 4:
        print("用法: python _quick_assign.py <类型> <等级> <部门> [描述]")
        print("  类型: bug|feature|maintenance|emergency")
        print("  等级: S1|S2|S3|S4")
        print("  部门:", list(DEPT_FILES.keys()))
        sys.exit(1)
    
    task_type = sys.argv[1]
    severity = sys.argv[2]
    dept = sys.argv[3]
    description = " ".join(sys.argv[4:]) if len(sys.argv) > 4 else "未指定"
    
    if dept not in DEPT_FILES:
        print(f"❌ 未知部门: {dept}")
        print(f"   可选: {list(DEPT_FILES.keys())}")
        sys.exit(1)
    
    create_task(task_type, severity, dept, description)
