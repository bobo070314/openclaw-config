# 集团统一执行入口指南

## 为什么需要这个

之前 CEO 反复因为 PowerShell 引号冲突导致 Python 脚本执行失败。集团为此耗费了大量人工。现在禁止所有内联 PowerShell Python 执行。

## 统一规则

**所有 Python 脚本必须通过 `_tools_run.py` 执行。**

唯一的调用格式（由 CEO/自动化部门验证通过）：

```powershell
$env:PYTHONIOENCODING="utf-8"
C:\Python314\python.exe D:\bobo\openclaw-foreign\workspace\_tools_run.py <脚本路径> [参数]
```

## 各部门常用脚本

### 数据部门
```powershell
_tools_run.py family-corp-tasks\_quick_assign.py bug S1 数据部门 "问题描述"
_tools_run.py family-corp-tasks\_sla_check.py
```

### IT部门
```powershell
_tools_run.py family-corp-tasks\_quick_assign.py bug S2 IT部门 "问题描述"
```

### 自动化部门
```powershell
_tools_run.py family-corp-tasks\_quick_assign.py feature S3 自动化部门 "问题描述"
```

### 绩效部门
```powershell
_tools_run.py family-corp-tasks\_quick_assign.py maintenance S3 绩效部门 "问题描述"
_tools_run.py family-corp-tasks\_sla_check.py
```

### 行政部门
```powershell
_tools_run.py family-corp-tasks\_quick_assign.py maintenance S4 行政部门 "问题描述"
```

## caipiao1 项目专用

```powershell
# 管道全自动
C:\Python314\python.exe C:\Users\asus\Desktop\caipiao1\core\full_pipeline.py --force

# 健康诊断
C:\Python314\python.exe <脚本路径>

# 对比报告
C:\Python314\python.exe C:\Users\asus\Desktop\caipiao1\core\post_draw_comparator.py --report
```

## 禁止事项（违规一次 P1 警告）

- ❌ 禁止在 PowerShell 中用 `python -c "<内联代码>"` 
- ❌ 禁止用 `& .venv\Scripts\python.exe` 跨项目调用
- ❌ 禁止用 `Get-Content | python` 管道
- ❌ 禁止用 Select-String 过滤 exec 的输出

## 允许的例外

`which` / `where` / `Get-ChildItem` / `Get-Content` / `Test-Path` 等纯 PowerShell 命令不受限。
纯 shell 命令（npm, git, node）不受限。
