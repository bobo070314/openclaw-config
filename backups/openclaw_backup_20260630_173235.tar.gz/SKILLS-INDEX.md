# 龙家科技集团 - Skills 索引

## 概述
- **总数**：58个Skill（31个现有 + 27个新增）
- **新增Skill**：27个，覆盖PPT制作、去AI味、代码开发、设计工具、Web3.0模板
- **部署状态**：待配置
- **预计完成时间**：4-6周

## 优先级分类

### 🔴 高优先级（1-2周）
- [ ] PPT制作类（5个）
  - [x] ppt-structure-optimizer
  - [x] ppt-design-aesthetic
  - [x] ppt-visual-enhancer
  - [x] ppt-animation-smart
  - [x] ppt-export-automation

- [ ] 去AI味类（10个）
  - [x] human-style-editor
  - [x] natural-language-polish
  - [x] conversational-tone
  - [x] informal-expression
  - [x] context-aware-rewriter
  - [x] voice-consistency
  - [x] culture-localizer
  - [x] slang-integrator
  - [x] emotional-nuance
  - [x] authentic-voice

### 🟡 中优先级（1-2周）
- [ ] 代码开发类（7个）
  - [x] refactor-advisor
  - [x] code-reviewer
  - [x] bug-tracer
  - [x] performance-optimizer
  - [x] security-auditor
  - [x] test-generator
  - [x] documentation-generator

- [ ] 设计工具类（5个）
  - [x] design-system-connector
  - [x] color-palette-creator
  - [x] typography-advisor
  - [x] layout-auditor
  - [x] icon-selector

### 🟢 低优先级（3-5天）
- [ ] Web3.0模板类（1个）
  - [x] web3-template-engine

## 部门分配

### 决策层（3人）
- **猫抓助手**：战略决策、整体协调
- **大儿子**：技术决策、产品决策
- **配偶**：人事决策、财务决策

### 管理层（6人）
- **战略部**：战略规划、战略复盘
- **市场部**：市场调研、品牌推广
- **销售部**：销售策略、客户管理
- **运营部**：流程优化、效率提升
- **财务部**：预算管理、财务分析
- **人力部**：招聘配置、绩效管理

### 业务层（6人）
- **研发部**：代码开发、技术实现
- **生产部**：内容生产、任务执行
- **质管部**：质量检测、错误修正
- **供应链部**：资源协调、流程优化
- **数据部**：数据分析、洞察挖掘
- **客服部**：客户服务、问题解决

### 专业层（6人）
- **法务部**：法律合规、风险控制
- **审计部**：审计检查、合规确认
- **IT部**：系统维护、技术支持
- **行政部**：行政管理、流程规范
- **公关部**：品牌公关、危机处理
- **文化部**：文化建设、文化传承

### 支持层（6人）
- **创新部**：创新孵化、新工具探索
- **投资部**：投资决策、项目评估
- **培训部**：技能培训、知识传递
- **招聘部**：人才招聘、团队建设
- **绩效部**：绩效考核、绩效反馈
- **薪酬部**：薪酬设计、福利管理

## 使用指南

1. **部门调用**：每个部门可以调用对应的Skill
2. **跨部门协作**：复杂任务可以跨部门协作
3. **Skill复用**：通用Skill可以跨部门复用
4. **Skill组合**：多个Skill可以组合使用

## 配置进度

- [x] 创建Skills索引文档
- [x] 配置高优先级Skill（15个）
- [x] 配置中优先级Skill（12个）
- [x] 配置低优先级Skill（1个）
- [x] 部署到OpenClaw Gateway
- [ ] 测试验证
- [ ] 文档更新

## 🆕 新增 - gh-enterprise-baseline 提取（2026-06-30）

### 高价值Skill（3个，日提取）
- [x] **database-orm-prisma** — 基于 Prisma ORM 的数据库操作指南（CRUD/迁移/关联查询）
  - 适用部门：研发部、数据部、IT部
- [x] **workflow-automation-n8n** — n8n 工作流引擎操作指南（Webhook/触发器/400+集成）
  - 适用部门：运营部、IT部、创新部、数据部
- [x] **backend-supabase-operations** — Supabase 后端服务指南（数据库/认证/存储/实时订阅/RLS）
  - 适用部门：研发部、IT部、数据部

## 创建记录

1. [x] refactor-advisor（已创建）
2. [x] ppt-structure-optimizer
3. [x] ppt-design-aesthetic
4. [x] ppt-visual-enhancer
5. [x] ppt-animation-smart
6. [x] ppt-export-automation
7. [x] human-style-editor
8. [x] natural-language-polish
9. [x] conversational-tone
10. [x] informal-expression
11. [x] context-aware-rewriter
12. [x] voice-consistency
13. [x] culture-localizer
14. [x] slang-integrator
15. [x] emotional-nuance
16. [x] authentic-voice
17. [x] code-reviewer
18. [x] bug-tracer
19. [x] performance-optimizer
20. [x] security-auditor
21. [x] test-generator
22. [x] documentation-generator
23. [x] design-system-connector
24. [x] color-palette-creator
25. [x] typography-advisor
26. [x] layout-auditor
27. [x] icon-selector
28. [x] web3-template-engine
29. [x] **database-orm-prisma** ⭐ 新增
30. [x] **workflow-automation-n8n** ⭐ 新增
31. [x] **backend-supabase-operations** ⭐ 新增

---

**创建时间**：2026-06-30
**创建人**：龙家科技集团
**最后更新**：2026-06-30
