"""gateway 看门狗 — 检查 gateway 进程是否存活"""
import subprocess

def check_gateway():
    try:
        r = subprocess.run(["netstat", "-ano"], capture_output=True, text=False, timeout=10)
        stdout = r.stdout.decode("gbk", errors="replace") if isinstance(r.stdout, bytes) else str(r.stdout)
        if ":18900" in stdout:
            return {"status": "OK", "msg": "gateway 18900 LISTENING"}
        return {"status": "FAIL", "msg": "gateway 18900 未监听"}
    except Exception as e:
        return {"status": "FAIL", "msg": f"检测失败: {e}"}

def main():
    result = check_gateway()
    if result["status"] != "OK":
        print(f"[gateway-watcher] {result['msg']}")

if __name__ == "__main__":
    main()
