"""cron 看门狗 — 检查37个cron任务执行状态"""
import subprocess
import json
import sys
from pathlib import Path

def check_cron_jobs():
    try:
        r = subprocess.run(["node", "-e", "const c=require('./openclaw/gateway/cron');c.list().then(j=>console.log(JSON.stringify(j.filter(x=>x.enabled!==false).length)))".replace("./", "D:/bobo/openclaw-foreign/")],
                         capture_output=True, text=True, timeout=15, shell=True,
                         env={"PYTHONIOENCODING": "utf-8"})
        return {"status": "OK", "msg": r.stdout.strip() if r.stdout.strip() else "检查完成"}
    except Exception as e:
        return {"status": "WARN", "msg": f"cron检查失败: {e}"}

def main():
    result = check_cron_jobs()
    if result["status"] != "OK":
        print(json.dumps(result))
        
if __name__ == "__main__":
    main()
