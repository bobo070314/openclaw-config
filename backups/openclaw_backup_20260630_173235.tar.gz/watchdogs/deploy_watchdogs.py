"""部署看门狗到秒级轮询

运行方式:
  C:\Python314\python.exe watchdogs\deploy_watchdogs.py

说明:
  在 OpenClaw cron 中注册定时看门狗扫描任务
  使用高频率 cron（每5-10分钟）实现"准实时"自下而上发现问题
"""
import json, sys, subprocess
from pathlib import Path

WORKSPACE = Path(__file__).resolve().parent.parent
PYTHON = "C:\\Python314\\python.exe"

WATCHERS = [
    {
        "name": "caipiao1-watcher",
        "expr": "*/10 * * * *",
        "script": "watchdogs\\caipiao1_watcher.py",
        "description": "caipiao1 数据链路看门狗 (每10分钟)"
    },
    {
        "name": "gateway-watcher",
        "expr": "*/5 * * * *",
        "script": "watchdogs\\gateway_watcher.py",
        "description": "gateway 进程看门狗 (每5分钟)"
    },
    {
        "name": "cron-watcher",
        "expr": "*/30 * * * *",
        "script": "watchdogs\\cron_watcher.py",
        "description": "cron 任务执行状态检查 (每30分钟)"
    },
]

def deploy():
    """通过 openclaw cron API 注册 watcher 任务"""
    for w in WATCHERS:
        cmd = f'"{PYTHON}" "{WORKSPACE / w["script"]}"'
        job = {
            "name": w["name"],
            "schedule": {"kind": "cron", "expr": w["expr"], "tz": "Asia/Shanghai"},
            "payload": {
                "kind": "agentTurn",
                "message": f"执行看门狗: {cmd}"
            },
            "sessionTarget": "isolated",
            "description": w["description"],
            "enabled": True,
            "deleteAfterRun": True,
        }
        
        # 通过 API 注册
        import requests
        try:
            r = requests.post(
                "http://localhost:18900/api/cron/add",
                json=job,
                timeout=10,
                headers={"Content-Type": "application/json"}
            )
            if r.status_code == 200:
                print(f"✅ {w['name']} 已部署 (每{w['expr']})")
            else:
                print(f"⚠️ {w['name']} 返回 {r.status_code}: {r.text}")
        except requests.exceptions.ConnectionError:
            # 如果不走API，fallback 到 openclaw CLI
            print(f"⚠️ {w['name']} API不通, 跳过 (需要手动部署)")
        except ImportError:
            print(f"⚠️ {w['name']} requests 模块未安装, 跳过API部署")


if __name__ == "__main__":
    deploy()
