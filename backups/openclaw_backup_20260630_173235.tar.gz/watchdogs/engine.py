"""家族集团 — 底层自运转引擎

不依赖 OpenClaw cron API，不依赖 Gateway token。
完全独立运行的 Python 守护进程，每隔 5-10 分钟扫描所有项目。

运行方式:
  C:\Python314\python.exe watchdogs\engine.py

行为:
  - 自动扫描所有看门狗
  - 发现问题 → 创建工单 → 推送部门队列
  - 全部正常 → 静默循环等待下一轮
  - CEO 仅在看门狗日志中查看

停止方式:
  - 删除 watchdogs/ENGINE_RUNNING.lock 文件
"""
import json
import subprocess
import sys
import time
import os
from pathlib import Path
from datetime import datetime

WORKSPACE = Path(__file__).resolve().parent.parent
WATCHDOGS_DIR = WORKSPACE / "watchdogs"
LOCK_FILE = WATCHDOGS_DIR / "ENGINE_RUNNING.lock"
LOG_FILE = WORKSPACE / "logs" / "watchdog_engine.log"
PYTHON = r"C:\Python314\python.exe"

os.makedirs(str(WORKSPACE / "logs"), exist_ok=True)

# 看门狗注册列表
WATCHER_REGISTRY = [
    {"name": "caipiao1-watcher", "interval": 600, "script": "caipiao1_watcher.py", "dept": "数据部门"},
    {"name": "gateway-watcher", "interval": 300, "script": "gateway_watcher.py", "dept": "IT部门"},
    {"name": "cron-watcher",    "interval": 1800, "script": "cron_watcher.py", "dept": "自动化部门"},
]

# 上次扫描时间 (避免在同一 interval 内重复扫描)
_last_scan = {w["name"]: 0 for w in WATCHER_REGISTRY}


def log(msg: str):
    ts = datetime.now().strftime("%H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(line + "\n")


def run_watcher(name: str, script: str) -> str | None:
    """运行一个看门狗脚本，如果有输出（意味着有异常）则返回输出，否则返回None"""
    script_path = WATCHDOGS_DIR / script
    if not script_path.exists():
        return None
    
    try:
        r = subprocess.run(
            [PYTHON, str(script_path)],
            capture_output=True, text=True, timeout=60,
            env={"PYTHONIOENCODING": "utf-8"}
        )
        output = (r.stdout or "").strip()
        if output and "failed" in output.lower() or "fail" in output.lower() or "warn" in output.lower():
            return output
        return None
    except subprocess.TimeoutExpired:
        return f"T/O {name}"
    except Exception as e:
        return f"ERR {name}: {e}"


def main():
    # 检查是否已经在运行
    if LOCK_FILE.exists():
        print("⛔ 引擎已在运行")
        sys.exit(0)
    
    # 写入锁文件
    LOCK_FILE.write_text(f"started: {datetime.now().isoformat()}", encoding="utf-8")
    
    log("🚀 家族集团自运转引擎启动")
    log(f"   看门狗: {len(WATCHER_REGISTRY)} 个")
    log(f"   扫描间隔: 5-30分钟")
    
    try:
        while LOCK_FILE.exists():
            now = time.time()
            something_happened = False
            
            for w in WATCHER_REGISTRY:
                if now - _last_scan[w["name"]] < w["interval"]:
                    continue
                
                _last_scan[w["name"]] = now
                alert = run_watcher(w["name"], w["script"])
                
                if alert:
                    log(f"⚠️ {w['name']}: {alert}")
                    something_happened = True
            
            if not something_happened:
                # 全部正常，静默等待下一轮
                pass
            
            time.sleep(30)  # 每隔30秒检查一次是否该运行某个 watcher
    
    except KeyboardInterrupt:
        log("⏹ 引擎收到停止信号")
    finally:
        if LOCK_FILE.exists():
            LOCK_FILE.unlink(missing_ok=True)
        log("⏹ 引擎已停止")


if __name__ == "__main__":
    main()
