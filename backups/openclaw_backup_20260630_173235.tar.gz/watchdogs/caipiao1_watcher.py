"""caipiao1 看门狗 — 每10分钟自动扫描数据链路健康度

运行方式 (通过 cron 定时触发):
  C:\Python314\python.exe D:\bobo\openclaw-foreign\workspace\watchdogs\caipiao1_watcher.py

行为:
  ✅ 全部正常 → 静默退出 (无输出)
  ⚠️ 有异常 → 创建工单推送到部门队列
"""
import json
import subprocess
import sys
from pathlib import Path
from datetime import datetime

# === 配置 ===
WORKSPACE = Path(r"D:\bobo\openclaw-foreign\workspace")
CAIPIAO1 = Path(r"C:\Users\asus\Desktop\caipiao1")
SCRIPTS_DIR = WORKSPACE / "family-corp-tasks"
WATCHDOGS_DIR = WORKSPACE / "watchdogs"
PYTHON_EXE = r"C:\Python314\python.exe"
QUICK_ASSIGN = str(SCRIPTS_DIR / "_quick_assign.py")

# === 探查函数 ===

def check_ssq_latest() -> dict:
    """检查 ssq.csv 最新数据"""
    csv_path = CAIPIAO1 / "data" / "ssq.csv"
    if not csv_path.exists():
        return {"status": "FAIL", "msg": "ssq.csv 不存在"}
    
    with open(csv_path, encoding="utf-8") as f:
        last = f.readlines()[-1].strip().split(",")
    
    period = last[8] if len(last) > 8 else "?"
    date = last[0]
    
    # 检查是否7天内有更新
    try:
        d = datetime.strptime(date, "%Y-%m-%d")
        age = (datetime.now() - d).days
        if age > 7:
            return {"status": "WARN", "msg": f"ssq.csv 最后更新 {date} ({age}天前)", "period": period}
    except ValueError:
        pass
    
    return {"status": "OK", "msg": f"最新: {period} ({date})"}


def check_bet_records() -> dict:
    """检查 bet_records.json 是否有最新期号"""
    br_path = CAIPIAO1 / ".cache" / "bet_records.json"
    if not br_path.exists():
        return {"status": "FAIL", "msg": "bet_records.json 不存在"}
    
    try:
        data = json.loads(br_path.read_text(encoding="utf-8"))
        if not data:
            return {"status": "WARN", "msg": "bet_records.json 为空"}
        
        last_period = data[-1].get("draw_period", "")
        count = len(data)
        
        # 检查最后一条是否5天内
        last_date = data[-1].get("bet_date", "")
        if last_date:
            try:
                d = datetime.strptime(last_date, "%Y-%m-%d")
                age = (datetime.now() - d).days
                if age > 5:
                    return {"status": "WARN", "msg": f"bet_records 最后更新 {last_date} ({age}天前)", "last_period": last_period}
            except ValueError:
                pass
        
        return {"status": "OK", "msg": f"{count}条, 最新: {last_period}"}
    except Exception as e:
        return {"status": "FAIL", "msg": f"读取异常: {e}"}


def check_comparison_history() -> dict:
    """检查 comparison_history.json"""
    ch_path = CAIPIAO1 / ".cache" / "comparison_history.json"
    if not ch_path.exists():
        return {"status": "WARN", "msg": "comparison_history.json 未生成"}
    
    try:
        data = json.loads(ch_path.read_text(encoding="utf-8"))
        if not data:
            return {"status": "WARN", "msg": "comparison_history 为空"}
        return {"status": "OK", "msg": f"{len(data)} 期对比记录"}
    except Exception as e:
        return {"status": "FAIL", "msg": f"读取异常: {e}"}


def check_port(port: int, name: str) -> dict:
    """检查端口是否监听"""
    try:
        r = subprocess.run(["netstat", "-ano"], capture_output=True, text=False, timeout=10)
        stdout = r.stdout.decode("gbk", errors="replace") if isinstance(r.stdout, bytes) else str(r.stdout)
        if f":{port}" in stdout:
            return {"status": "OK", "msg": f"{name} 端口 {port} LISTENING"}
        return {"status": "WARN", "msg": f"{name} 端口 {port} 未监听"}
    except Exception as e:
        return {"status": "FAIL", "msg": f"端口检测失败: {e}"}


def create_watchdog_ticket(dept: str, severity: str, description: str):
    """创建工单"""
    try:
        subprocess.run(
            [PYTHON_EXE, QUICK_ASSIGN, "bug", severity, dept, description],
            capture_output=True, text=True, timeout=30,
            env={"PYTHONIOENCODING": "utf-8"}
        )
    except Exception:
        pass  # 静默处理，不阻塞主流程


# === 主流程 ===

def main():
    checks = {
        "ssq": check_ssq_latest(),
        "bet_records": check_bet_records(),
        "comparison": check_comparison_history(),
        "port_8501": check_port(8501, "看板v1"),
        "port_8502": check_port(8502, "看板v2"),
        "port_8088": check_port(8088, "后端API"),
    }
    
    # 扫描到异常
    issues = []
    for name, result in checks.items():
        if result["status"] != "OK":
            issues.append((name, result))
    
    if not issues:
        # 全部正常 → 静默退出
        return
    
    # 有异常 → 创建工单组
    problem_desc = "; ".join(f"{n}: {r['msg']}" for n, r in issues)
    
    # 根据问题类型确定责任部门
    if "ssq" in problem_desc or "bet_records" in problem_desc or "comparison" in problem_desc:
        dept = "数据部门"
    elif "port" in problem_desc:
        dept = "IT部门"
    else:
        dept = "运营部门"
    
    # 确定严重等级
    fails = sum(1 for _, r in issues if r["status"] == "FAIL")
    severity = "S1" if fails > 0 else "S2"
    
    create_watchdog_ticket(dept, severity, f"caipiao1看门狗: {problem_desc}")
    
    # 输出摘要（给 cron 日志用）
    print(f"[caipiao1-watcher] {len(issues)}个异常, 责任:{dept}, 等级:{severity}")
    for n, r in issues:
        print(f"  [{r['status']}] {n}: {r['msg']}")


if __name__ == "__main__":
    main()
